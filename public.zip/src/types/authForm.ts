export interface AuthForm {
  email: string;
  password: string;
  confirmPassword?: string;
  name?: string;
}
