import { createFileRoute, FileRoutesByPath } from "@tanstack/react-router";

export const Route = createFileRoute("/purchase-orders/$uuid")({
  component: PostComponent,
});

function PostComponent() {
  const { postId } = Route.useParams();
  return <div>Post {postId}</div>;
}
